
//----------------------------------------------------------------------------
// sprite ids
#define IDS_HANDIDLE			0x0001
#define IDS_HANDMACH			0x0002
#define IDS_HANDLEFT			0x0003
#define IDS_HANDRIGHT			0x0004
#define IDS_HANDFWD				0x0005
#define IDS_HANDBACK			0x0006
#define IDS_HANDUP				0x0007
#define IDS_HANDDOWN			0x0008
#define IDS_HANDUPLT			0x0009
#define IDS_HANDUPRT			0x000a  
#define IDS_HANDDNLT			0x000b
#define IDS_HANDDNRT			0x000c
#define IDS_HANDALT				0x000d
#define IDS_HANDTRIG			0x000e
#define IDS_HANDCLICK			0x000f
#define IDS_OTHERHAND			0x0010

#define IDS_BTN_QUIT			0x0020
#define IDS_BTN_CREDITS			0x0021
#define IDS_BTN_AUDIO			0x0022
#define IDS_BTN_PLAYER			0x0023
#define IDS_BTN_GAME			0x0024
#define IDS_BTN_NETWORK			0x0025
#define IDS_BTN_HELP			0x0026

#define IDS_BTN_NEW				0x0027
#define IDS_BTN_NEW_HI			0x0028
#define IDS_BTN_OK				0x0029
#define IDS_BTN_OK_HI			0x002a
#define IDS_BTN_DELETE			0x002b
#define IDS_BTN_DELETE_HI		0x002c
#define IDS_BTN_SAVE			0x002d
#define IDS_BTN_SAVE_HI			0x002e
#define IDS_BTN_LOAD			0x002f
#define IDS_BTN_LOAD_HI			0x0030
#define IDS_BTN_CANCEL			0x0031
#define IDS_BTN_CANCEL_HI		0x0032

// frames for listboxes and editboxes
#define IDS_STD_LISTBOXS		0x0040
#define IDS_STD_LISTBOXM		0x0041
#define IDS_STD_LISTBOXL		0x0042
#define IDS_STD_EDITBOXS		0x0043
#define IDS_STD_EDITBOXM		0x0044
#define IDS_STD_EDITBOXL		0x0045

// arrow keys for list boxes and sliders
#define IDS_BTN_LEFT			0x0050
#define IDS_BTN_LEFT_HI			0x0051
#define IDS_BTN_RIGHT			0x0052
#define IDS_BTN_RIGHT_HI		0x0053
#define IDS_BTN_UP				0x0054
#define IDS_BTN_UP_HI			0x0055
#define IDS_BTN_DOWN			0x0056
#define IDS_BTN_DOWN_HI			0x0057
#define IDS_BTN_THUMB			0x0058

// check boxes for player config
#define IDS_BTN_VILCULT			0x0060
#define IDS_BTN_VILCULT_HI		0x0061
#define IDS_BTN_CITCULT			0x0062
#define IDS_BTN_CITCULT_HI		0x0063
#define IDS_BTN_FEMALE			0x0064
#define IDS_BTN_FEMALE_HI		0x0065
#define IDS_BTN_MALE			0x0066
#define IDS_BTN_MALE_HI			0x0067

#define IDS_TXT_MUSIC			0x0070
#define IDS_TXT_SFX				0x0071

#define IDS_FONTENG				0x00a0
#define IDS_FONTPAR				0x00a1
#define IDS_FONTVILL			0x00a2
#define IDS_FONTCITY			0x00a3

#define IDS_FONTENG_BIG			0x00a4
#define IDS_FONTPAR_BIG			0x00a5
#define IDS_FONTVILL_BIG		0x00a6
#define IDS_FONTCITY_BIG		0x00a7

#define IDS_FONTTNR12			0x00a8
#define IDS_FONTTNR14			0x00a9
#define IDS_FONTTNR16			0x00aa
#define IDS_FONTTNR18			0x00ab
#define IDS_FONTTNB12			0x00ac
#define IDS_FONTTNB14			0x00ad
#define IDS_FONTTNB16			0x00ae
#define IDS_FONTTNB18			0x00af

#define IDS_REDDOT				0x00d8
#define IDS_REDEAR				0x00d9

#define IDS_NYSVIAL			0x00e0
#define IDS_SCOOPF			0x00e1
#define IDS_SCOOPE			0x00e2

#define IDS_HALO00			0x00f0
#define IDS_HALO01			0x00f1
#define IDS_HALO02			0x00f2
#define IDS_HALO03			0x00f3
#define IDS_HALO04			0x00f4
#define IDS_HALO05			0x00f5
#define IDS_HALO06			0x00f6
#define IDS_HALO07			0x00f7


// id sprites run from 0x0100 .. 0x01c7
// don't change the ID numbers, please!
#define IDp_xxHAPPY		0x0000
#define IDp_xxHURT		0x0001
#define IDp_xxKISS		0x0002
#define IDp_xxMAD		0x0003
#define IDp_xxSAD		0x0004
#define IDp_xxSURPRISED	0x0005
#define IDp_xxSTRESS	0x0006
#define IDp_xxWAVE		0x0007

#define EMOTIONS_PER_LEVEL	0x0010
#define MAX_LEVEL		5

#define IDp_FEMALE		0x0100
#define IDp_MALE		0x0160

#define IDS_F0HAPPY		0x0100
#define IDS_F0HURT		0x0101
#define IDS_F0KISS		0x0102
#define IDS_F0MAD		0x0103
#define IDS_F0SAD		0x0104
#define IDS_F0SUPRISED	0x0105
#define IDS_F0STRESS	0x0106
#define IDS_F0WAVE		0x0107

#define IDS_F1HAPPY		0x0110
#define IDS_F1HURT		0x0111
#define IDS_F1KISS		0x0112
#define IDS_F1MAD		0x0113
#define IDS_F1SAD		0x0114
#define IDS_F1SUPRISED	0x0115
#define IDS_F1STRESS	0x0116
#define IDS_F1WAVE		0x0117

#define IDS_F2HAPPY		0x0120
#define IDS_F2HURT		0x0121
#define IDS_F2KISS		0x0122
#define IDS_F2MAD		0x0123
#define IDS_F2SAD		0x0124
#define IDS_F2SUPRISED	0x0125
#define IDS_F2STRESS	0x0126
#define IDS_F2WAVE		0x0127

#define IDS_F3HAPPY		0x0130
#define IDS_F3HURT		0x0131
#define IDS_F3KISS		0x0132
#define IDS_F3MAD		0x0133
#define IDS_F3SAD		0x0134
#define IDS_F3SUPRISED	0x0135
#define IDS_F3STRESS	0x0136
#define IDS_F3WAVE		0x0137

#define IDS_F4HAPPY		0x0140
#define IDS_F4HURT		0x0141
#define IDS_F4KISS		0x0142
#define IDS_F4MAD		0x0143
#define IDS_F4SAD		0x0144
#define IDS_F4SUPRISED	0x0145
#define IDS_F4STRESS	0x0146
#define IDS_F4WAVE		0x0147

#define IDS_F5HAPPY		0x0150
#define IDS_F5HURT		0x0151
#define IDS_F5KISS		0x0152
#define IDS_F5MAD		0x0153
#define IDS_F5SAD		0x0154
#define IDS_F5SUPRISED	0x0155
#define IDS_F5STRESS	0x0156
#define IDS_F5WAVE		0x0157

#define IDS_M0HAPPY		0x0160
#define IDS_M0HURT		0x0161
#define IDS_M0KISS		0x0162
#define IDS_M0MAD		0x0163
#define IDS_M0SAD		0x0164
#define IDS_M0SUPRISED	0x0165
#define IDS_M0STRESS	0x0166
#define IDS_M0WAVE		0x0167

#define IDS_M1HAPPY		0x0170
#define IDS_M1HURT		0x0171
#define IDS_M1KISS		0x0172
#define IDS_M1MAD		0x0173
#define IDS_M1SAD		0x0174
#define IDS_M1SUPRISED	0x0175
#define IDS_M1STRESS	0x0176
#define IDS_M1WAVE		0x0177

#define IDS_M2HAPPY		0x0180
#define IDS_M2HURT		0x0181
#define IDS_M2KISS		0x0182
#define IDS_M2MAD		0x0183
#define IDS_M2SAD		0x0184
#define IDS_M2SUPRISED	0x0185
#define IDS_M2STRESS	0x0186
#define IDS_M2WAVE		0x0187

#define IDS_M3HAPPY		0x0190
#define IDS_M3HURT		0x0191
#define IDS_M3KISS		0x0192
#define IDS_M3MAD		0x0193
#define IDS_M3SAD		0x0194
#define IDS_M3SUPRISED	0x0195
#define IDS_M3STRESS	0x0196
#define IDS_M3WAVE		0x0197

#define IDS_M4HAPPY		0x01a0
#define IDS_M4HURT		0x01a1
#define IDS_M4KISS		0x01a2
#define IDS_M4MAD		0x01a3
#define IDS_M4SAD		0x01a4
#define IDS_M4SUPRISED	0x01a5
#define IDS_M4STRESS	0x01a6
#define IDS_M4WAVE		0x01a7

#define IDS_M5HAPPY		0x01b0
#define IDS_M5HURT		0x01b1
#define IDS_M5KISS		0x01b2
#define IDS_M5MAD		0x01b3
#define IDS_M5SAD		0x01b4
#define IDS_M5SUPRISED	0x01b5
#define IDS_M5STRESS	0x01b6
#define IDS_M5WAVE		0x01b7


//---- These are the Id's pedistals //

#define IDS_PED1		0x01c0
#define IDS_PED2		0x01c1
#define IDS_PED3		0x01c2
#define IDS_PED4		0x01c3
#define IDS_PED5		0x01c4
#define IDS_PED6		0x01c5
#define IDS_PED7		0x01c6
#define IDS_PED8		0x01c7
#define IDS_PED9		0x01c8
#define IDS_PED10		0x01c9

//---- These are the Id's Auras //

#define IDS_AURA1		0x01da
#define IDS_AURA2		0x01db
#define IDS_AURA3		0x01dc

//-------------------------------
// Scene 2 sprites:
#define IDS_CITY_KEY	0x0200
#define IDS_LOCKWKEY	0x0201
#define IDS_CITYNUM		0x0202

#define IDS_RED_SLIDE	0x0203
#define IDS_BLU_SLIDE	0x0204
#define IDS_GRN_SLIDE	0x0205

#define IDS_KEY_CFGWKEY	0x0206
#define IDS_KEY_IN_BIN	0x0207


#define IDS_FLOWER0		0x0270
// .... RESERVED RANGE - FLOWER1..FLOWER8
#define IDS_FLOWER9		0x0279

#define IDS_PIT00		0x0280
#define IDS_PIT01		0x0281
#define IDS_PIT02		0x0282
#define IDS_PIT03		0x0283
#define IDS_PIT04		0x0284
#define IDS_PIT05		0x0285
#define IDS_PIT06		0x0286
#define IDS_PIT07		0x0287
#define IDS_PIT08		0x0288
#define IDS_PIT09		0x0289


//--------------------------------
// Scene 05: Chem Lab 101.
#define IDS_CHEMV01	0x0500
#define IDS_CHEMV02	0x0501
#define IDS_CHEMV03	0x0502
#define IDS_CHEMV04	0x0503
#define IDS_CHEMV05	0x0504
#define IDS_CHEMV06	0x0505
#define IDS_CHEMV07	0x0506
#define IDS_CHEMV08	0x0507
#define IDS_CHEMV09	0x0508
#define IDS_CHEMV10	0x0509
#define IDS_CHEMV11	0x050a
#define IDS_CHEMV12	0x050b
#define IDS_CHEMV13	0x050c
#define IDS_CHEMV14	0x050d
#define IDS_CHEMV15	0x050e
#define IDS_CHEMV16	0x050f
#define IDS_CHEMV17	0x0510
#define IDS_CHEMV18	0x0511
#define IDS_CHEMV19	0x0512
#define IDS_CHEMV20	0x0513

#define IDS_CHEMS		0x0520
#define IDS_CHEMFILL	0x0521
#define IDS_CHEMBUBL	0x0522

// Scene 06: Library and Pez hell.
#define IDS_PEZPOP			0x0600

#define IDS_TEMPLATE01		0x0601
// ... lots more templates
#define IDS_TEMPLATE35		0x0635

#define IDS_VIALCNT		0x0660
#define IDS_TMORPH		0x0661

#define IDS_BEAMER		0x0800

// Scene 11: fishing and grilling out:
#define IDS_POLE1			0x1101
#define IDS_POLE2			0x1102

#define IDS_POLE1B			IDS_POLE1LCB
#define IDS_POLE2B			IDS_POLE1LCB

#define IDS_POLE1LCB		0x1110
#define IDS_POLE1LCL		0x1111
#define IDS_POLE1LCT		0x1112
#define IDS_POLE1LCU		0x1113
#define IDS_POLE1LOB		0x1114
#define IDS_POLE1LOL		0x1115
#define IDS_POLE1LOT		0x1116
#define IDS_POLE1LOU		0x1117

#define IDS_POLE1RCB		0x1120
#define IDS_POLE1RCL		0x1121
#define IDS_POLE1RCT		0x1122
#define IDS_POLE1RCU		0x1123
#define IDS_POLE1ROB		0x1124
#define IDS_POLE1ROL		0x1125
#define IDS_POLE1ROT		0x1126
#define IDS_POLE1ROU		0x1127

#define IDS_BAIT0			0x1130
#define IDS_BAIT1			0x1131
#define IDS_BAIT2			0x1132
#define IDS_BAIT3			0x1133
#define IDS_BAIT4			0x1134
#define IDS_BAIT5			0x1135
#define IDS_BAIT6			0x1136
#define IDS_BAIT7			0x1137
#define IDS_BAIT8			0x1138
#define IDS_BAIT9			0x1139

// prostate fish: (in inventory or frying on grill)
#define IDS_AFISH1			0x1140
#define IDS_AFISH2			0x1141
#define IDS_AFISH3			0x1142
#define IDS_AFISH4			0x1143
#define IDS_AFISH5			0x1144
#define IDS_AFISH6			0x1145
#define IDS_AFISH7			0x1146
#define IDS_AFISH8			0x1147
#define IDS_AFISH9			0x1148
#define IDS_AFISH10			0x1149

// dangling fish: (held in hand)
#define IDS_BFISH1		0x1150
#define IDS_BFISH2		0x1151
#define IDS_BFISH3		0x1152
#define IDS_BFISH4		0x1153
#define IDS_BFISH5		0x1154
#define IDS_BFISH6		0x1155
#define IDS_BFISH7		0x1156
#define IDS_BFISH8		0x1157
#define IDS_BFISH9		0x1158
#define IDS_BFISH10		0x1159

#define IDS_FISHASH1	0x1160
#define IDS_FISHASH2	0x1161
#define IDS_FISHASH3	0x1162
#define IDS_FISHASH4	0x1163
#define IDS_FISHASH5	0x1164
#define IDS_FISHASH6	0x1165
#define IDS_FISHASH7	0x1166
#define IDS_FISHASH8	0x1167
#define IDS_FISHASH9	0x1168
#define IDS_FISHASH10	0x1169

#define IDS_LOG		0x1170
#define IDS_MATCH		0x1171
#define IDS_WATER		0x1172
#define IDS_BUCKE		0x1173
#define IDS_BUCKF		0x1174

#define IDS_NEWSHOVL	0x1175
#define IDS_BOMB1		0x1176
#define IDS_BOMB2		0x1177
#define IDS_H2OMASK	0x1178
#define IDS_NYSMASK	0x1179

#define IDS_FISHWOOD	0x1188
#define IDS_BURNWOOD	0x1189
#define IDS_FISHASH		0x1190

#define IDS_VESTCAN		0x1191
#define IDS_VESTBNYS	0x1192
#define IDS_VESTH2O		0x1193

#define IDS_CITLOCK		0x1700
#define IDS_CITKEY		0x1701
#define IDS_VILLOCK		0x1702
#define IDS_VILKEY		0x1703
#define IDS_ROCK		0x1704
#define IDS_FORCEFLD	0x1705
#define IDS_MINEBLOW	0x1706
#define IDS_EXPLODE1	0x1707

#define IDS_FERNLEAF		0x2120
#define IDS_GLEAFSPT		0x2121
#define IDS_OMUSHSPT		0x2122
#define IDS_PFLWRSPT		0x2123
#define IDS_PLEAFSPT		0x2124
#define IDS_BLUEBERRY		0x2125
#define IDS_REDBERRY		0x2126
#define IDS_WFLWRSPT		0x2127
#define IDS_YFLWRSPT		0x2128
#define IDS_YMUSHSPT		0x2129

#define IDS_PNKPLANT		0x2130
#define IDS_FERN			0x2131
#define IDS_GRNPLANT		0x2132
#define IDS_OMUSH			0x2133
#define IDS_PFLOWER		0x2134
#define IDS_WFLOWER		0x2135
#define IDS_YFLOWER		0x2136
#define IDS_YMUSH			0x2137


#define IDS_SCR001		0x2201
#define IDS_SCR002		0x2202
#define IDS_SCR003		0x2203
#define IDS_SCR004		0x2204
#define IDS_SCR005		0x2205
#define IDS_SCR006		0x2206
#define IDS_SCR007		0x2207
#define IDS_SCR008		0x2208
#define IDS_SCR009		0x2209
#define IDS_SCR010		0x2210
#define IDS_SCR011		0x2211
#define IDS_SCR012		0x2212
#define IDS_SCR013		0x2213
#define IDS_SCR014		0x2214
#define IDS_SCR015		0x2215
#define IDS_SCR016		0x2216
#define IDS_SCR017		0x2217
#define IDS_SCR018		0x2218
#define IDS_SCR019		0x2219
#define IDS_SCR020		0x2220

#define IDS_SHLDSCRL		0x2221
#define IDS_PLNTSCRL		0x2222
#define IDS_FISHSCRL		0x2223
#define IDS_VIALSCRL		0x2224
#define IDS_WORDSCRL		0x2225

#define IDS_WKING			0x6000
#define IDS_WQUEEN			0x6001
#define IDS_WPAWN			0x6002
#define IDS_WROOK			0x6003
#define IDS_WKNIGHT			0x6004
#define IDS_WBISHOP			0x6005
#define IDS_WKINGME			0x6006

#define IDS_BKING			0x6008
#define IDS_BQUEEN			0x6009
#define IDS_BPAWN			0x600A
#define IDS_BROOK			0x600B
#define IDS_BKNIGHT			0x600C
#define IDS_BBISHOP			0x600D
#define IDS_BKINGME			0x600E

#define IDS_REVERSIA		0x6010
#define IDS_REVERSIB		0x6011
#define IDS_GOBTRFLY		0x6012
#define IDS_GODRAGON		0x6013
#define IDS_REVBIN_A		0x6014
#define IDS_REVBIN_B		0x6015
#define IDS_GOBIN_B			0x6016
#define IDS_GOBIN_D			0x6017

#define IDS_SPINSPELL	0x7000
#define IDS_SPINNER		0x7001
#define IDS_FREQUENCY	0x7002

#define IDS_SPIRIT0		0x7770
#define IDS_SPIRIT1		0x7771
#define IDS_SPIRIT2		0x7772
#define IDS_SPIRIT3		0x7773

#define IDS_SPRINGS		0x7774

#define IDS_SPELL01		0x7777
#define IDS_SPELL02		0x7778
#define IDS_SPELL03		0x7779
#define IDS_SPELL04		0x777A
#define IDS_SPELL05		0x777B
#define IDS_SPELL06		0x777C
#define IDS_SPELL07		0x777D
#define IDS_SPELL08		0x777E
#define IDS_SPELL09		0x777F
#define IDS_SPELL10		0x7780

#define IDS_SPELx01		0x7787
#define IDS_SPELx02		0x7788
#define IDS_SPELx03		0x7789
#define IDS_SPELx04		0x778A
#define IDS_SPELx05		0x778B
#define IDS_SPELx06		0x778C
#define IDS_SPELx07		0x778D
#define IDS_SPELx08		0x778E
#define IDS_SPELx09		0x778F
#define IDS_SPELx10		0x7790



